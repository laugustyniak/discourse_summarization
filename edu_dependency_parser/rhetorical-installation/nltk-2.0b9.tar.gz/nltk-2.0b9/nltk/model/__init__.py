# Natural Language Toolkit: Language Models
#
# Copyright (C) 2001-2010 NLTK Project
# Author: Steven Bird <sb@csse.unimelb.edu.au>
# URL: <http://www.nltk.org/>
# For license information, see LICENSE.TXT

from ngram import *

__all__ = [
    'NgramModel',
    ]
